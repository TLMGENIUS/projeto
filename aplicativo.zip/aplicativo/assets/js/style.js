document.getElementById('actionButton').addEventListener('click', function() {
    alert('Botão clicado!');
});