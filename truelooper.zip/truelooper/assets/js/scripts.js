/**
 * =================================================================================
 * SIDE NAVIGATION
 * =================================================================================
 */

const
    windowOverlay = document.querySelector('.window-overlay'),
    sideNavigation = document.querySelector('.side-navigation'),
    openSideNavigationBtn = document.querySelector('#openSideNavigation'),
    closeSideNavigationBtn = document.querySelector('#closeSideNavigation');

if (windowOverlay && sideNavigation && openSideNavigationBtn && closeSideNavigationBtn) {
    openSideNavigationBtn.addEventListener('click', () => {
        openSideNavigation();

        closeSideNavigationBtn.addEventListener('click', () => closeSideNavigation());

        window.addEventListener('click', (e) => {
            if (e.target == windowOverlay) closeSideNavigation();
        });
    });
}

let openSideNavigation = () => {
    windowOverlay.style.display = 'block';

    setTimeout(() => sideNavigation.style.left = '0', 200);
};

let closeSideNavigation = () => {
    sideNavigation.style.left = '-290px';

    setTimeout(() => windowOverlay.style.display = 'none', 200);
};

/**
 * =================================================================================
 * SHOW MORE (ASIDE GENRES)
 * =================================================================================
 */

const
    genresItems = document.querySelectorAll('.aside-genres__list-item'),
    showMoreGenresBtn = document.querySelector('#showMoreGenres');

if (genresItems && showMoreGenresBtn) {
    let displayItems = 14;

    for (let i = 0; i < displayItems; i++) {
        genresItems[i].style.display = 'block';
    }

    showMoreGenresBtn.addEventListener('click', () => {
        for (let i = 0; i < genresItems.length; i++) {
            if (genresItems[i].style.display != 'block') genresItems[i].style.display = 'block';
        }

        let count = 0;

        for (let i = 0; i < genresItems.length; i++) {
            if (genresItems[i].style.display != 'none') count++;
        }

        if (count == genresItems.length) showMoreGenresBtn.style.display = 'none';
    });
}

/**
 * =================================================================================
 * DESTAQUES
 * =================================================================================
 **/

const select = document.getElementById('card-type');
const containers = document.querySelectorAll('.card-container');

select.addEventListener('change', () => {
    containers.forEach(c => c.classList.remove('active')); // Esconde todos
    const selectedContainer = document.getElementById(select.value);
    if (selectedContainer) {
        selectedContainer.classList.add('active'); // Mostra o selecionado
    }
});

// Mostra o primeiro container ao carregar a página (opcional)
containers[0].classList.add('active'); // Mostra o primeiro por padrão

/**
 * =================================================================================
 * DESTAQUES
 * =================================================================================
 **/
/*
const images = document.querySelectorAll('#gallery img');
const navItems = document.querySelectorAll('nav li');
let currentIndex = 0;

function showImage(index) {
  images.forEach(img => img.classList.remove('active'));
  navItems.forEach(item => item.classList.remove('active'));

  images[index].classList.add('active');
  navItems[index].classList.add('active');
  currentIndex = index; // Atualiza o índice atual
}

navItems.forEach(item => {
  item.addEventListener('click', () => {
      const index = parseInt(item.dataset.index);
        showImage(index);
  });
});*/



/**
 * =================================================================================
 * DESTAQUES
 * =================================================================================
 **/

let items = document.querySelectorAll('.background-gallery .list .item');
let next = document.getElementById('next');
let prev = document.getElementById('prev');
let thumbnails = document.querySelectorAll('.thumbnail .item');
let controles = document.querySelectorAll('.controle .item');

// config param
let countItem = items.length;
let itemActive = 0;
// event next click
next.onclick = function () {
    itemActive = itemActive + 1;
    if (itemActive >= countItem) {
        itemActive = 0;
    }
    showgallery();
}
//event prev click
prev.onclick = function () {
    itemActive = itemActive - 1;
    if (itemActive < 0) {
        itemActive = countItem - 1;
    }
    showgallery();
}

// gallery
let refreshInterval = setInterval(() => {
    next.click();
}, 5000)

function showgallery() {
    // remove item active old
    let itemActiveOld = document.querySelector('.background-gallery .list .item.active');
    let thumbnailActiveOld = document.querySelector('.thumbnail .item.active');
    let controleActiveOld = document.querySelector('.controle .item.active');
    itemActiveOld.classList.remove('active');
    thumbnailActiveOld.classList.remove('active');
    controleActiveOld.classList.remove('active');

    // active new item
    items[itemActive].classList.add('active');
    thumbnails[itemActive].classList.add('active');
    controles[itemActive].classList.add('active');

    // clear auto time run gallery
    clearInterval(refreshInterval);
    refreshInterval = setInterval(() => {
        next.click();
    }, 5000)
}

// thumbnail
thumbnails.forEach((thumbnail, index) => {
    thumbnail.addEventListener('click', () => {
        itemActive = index;
        showgallery();
    })
})

// thumbnail
controles.forEach((controle, index) => {
    controle.addEventListener('click', () => {
        itemActive = index;
        showgallery();
    })
})



